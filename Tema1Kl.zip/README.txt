Apostu Croitoru Diana - 311CA
Read me

Taskul 1
	Am citit datele din fisier

Taskul 2
	Initializez random centroizii.Atribui o variabila ok
care imi verifica daca acestia sunt alesi corespunzator.
Calculez distanta minima dintre fiecare punct si centroid
si retin indicele centroidului corespunzator.Daca centroizii
nu se schimba ies din while,altfel gasesc ID-urile specifice
pentru fiecare grup.Daca exista grupuri care nu au niciun punct 
reinitializez centroizii,altfel recalculez centroizii.

Taskul 3
	Calculez distanta minima dintre fiecare punct si centroid.
Afisez pentru fiecare centroid punctele corespunzatoare in culori diferite.

Taskul 4
	Calculez distanta minima dintre fiecare punct si centroid.Fiecarui
centroid ii atribui o suma initiala = 0.Imi creez o matrice pentru 
fiecare centroid in care retin punctele specifice acestuia.Calculez 
individual fiecare suma.Costul va fi suma acestora.

Taskul 5
	Imi declar un vector p.Pentru un numar diferit de centroizi apelez
functia care ii calculeaza,respectiv costul specific acestora.Retin in
vector valoarea costului.Afisez graficul (cost,numar de centroizi).
	
	
